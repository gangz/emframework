package emframework.common.event;

public abstract class Event {
}
