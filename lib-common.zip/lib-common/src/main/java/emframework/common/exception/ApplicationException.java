package emframework.common.exception;

public abstract class ApplicationException extends Exception {

	public ApplicationException(String msg) {
		super(msg);
	}

}
