package emframework.common.security;

public class AuthorityValue {
	public static final String GUEST="ROLE_GUEST";
	public static final String NORMAL="ROLE_NORMAL";
	public static final String ADMIN="ROLE_ADMIN";
	public static final String ROOT="ROLE_ROOT";
	public static final String ACTUATOR="ROLE_ACTUATOR";
}
