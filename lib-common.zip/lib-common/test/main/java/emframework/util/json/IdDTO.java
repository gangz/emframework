package emframework.util.json;

public class IdDTO {

	private String id;
	public IdDTO(){}
	public IdDTO(String id) {
		this.setId(id);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
